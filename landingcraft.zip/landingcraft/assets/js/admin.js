/* =============================================
   LandingCraft — Admin Panel
   ============================================= */

'use strict';

// Navigation
document.querySelectorAll('.nav-item').forEach(item => {
  item.addEventListener('click', e => {
    e.preventDefault();
    const page = item.dataset.page;
    showPage(page);
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    item.classList.add('active');
  });
});

function showPage(name) {
  document.querySelectorAll('.admin-page').forEach(p => p.classList.remove('active'));
  const pg = document.getElementById('page-' + name);
  if (pg) pg.classList.add('active');
  document.getElementById('pageTitle').textContent = {
    dashboard: 'لوحة التحكم',
    pages: 'الصفحات',
    templates: 'القوالب',
    analytics: 'الإحصائيات',
    settings: 'الإعدادات'
  }[name] || name;
  document.querySelectorAll('.nav-item').forEach(n => {
    n.classList.toggle('active', n.dataset.page === name);
  });
}
window.showPage = showPage;

// Load Data
function loadDashboard() {
  const published = JSON.parse(localStorage.getItem('lc_published') || '[]');
  const current = JSON.parse(localStorage.getItem('lc_current') || '{}');

  // Stats
  document.getElementById('stat-pages').textContent = current.elements?.length > 0 ? 1 : 0;
  document.getElementById('stat-published').textContent = published.length;

  // Recent pages
  const recentDiv = document.getElementById('recentPages');
  const allDiv = document.getElementById('allPages');

  if (published.length === 0) {
    const emptyHTML = `<div class="empty-state">
      <div class="empty-state-icon">📄</div>
      <p>لا توجد صفحات منشورة بعد</p>
      <a href="index.html" class="btn-primary" style="display:inline-block;margin-top:12px;text-decoration:none">إنشاء صفحة جديدة</a>
    </div>`;
    recentDiv.innerHTML = emptyHTML;
    allDiv.innerHTML = emptyHTML;
    return;
  }

  const tableHTML = `<table class="pages-table">
    <thead>
      <tr>
        <th>اسم الصفحة</th>
        <th>الرابط</th>
        <th>المنصة</th>
        <th>التاريخ</th>
        <th>إجراءات</th>
      </tr>
    </thead>
    <tbody>
      ${published.map((p, i) => `<tr>
        <td><strong>${p.name || 'صفحة بلا اسم'}</strong></td>
        <td><a href="${p.url}" target="_blank" style="color:var(--accent)">${p.url}</a></td>
        <td><span class="badge badge-${p.platform === 'netlify' ? 'netlify' : p.platform === 'cloudflare' ? 'cf' : 'local'}">${p.platform === 'netlify' ? '▲ Netlify' : p.platform === 'cloudflare' ? '☁ Cloudflare' : '💾 محلي'}</span></td>
        <td>${p.date || '—'}</td>
        <td>
          <a href="${p.url}" target="_blank" class="btn-outline" style="padding:4px 10px;font-size:.78rem;text-decoration:none">👁 عرض</a>
          <button onclick="deletePage(${i})" style="background:transparent;border:1px solid #ff6584;color:#ff6584;padding:4px 10px;border-radius:6px;cursor:pointer;font-size:.78rem;margin-right:6px">🗑</button>
        </td>
      </tr>`).join('')}
    </tbody>
  </table>`;

  recentDiv.innerHTML = tableHTML;
  allDiv.innerHTML = tableHTML;
}

function deletePage(idx) {
  if (!confirm('هل تريد حذف هذه الصفحة من السجل؟')) return;
  const pages = JSON.parse(localStorage.getItem('lc_published') || '[]');
  pages.splice(idx, 1);
  localStorage.setItem('lc_published', JSON.stringify(pages));
  loadDashboard();
}
window.deletePage = deletePage;

// Settings
function saveNetlifySettings() {
  const token = document.getElementById('s-netlifyToken').value;
  const team = document.getElementById('s-netlifyTeam').value;
  localStorage.setItem('lc_netlify_token', token);
  localStorage.setItem('lc_netlify_team', team);
  showSettingsSaved('netlify-test-result', '✅ تم حفظ الإعدادات');
}
window.saveNetlifySettings = saveNetlifySettings;

function saveCFSettings() {
  localStorage.setItem('lc_cf_account', document.getElementById('s-cfAccount').value);
  localStorage.setItem('lc_cf_token', document.getElementById('s-cfToken').value);
  alert('✅ تم حفظ إعدادات Cloudflare');
}
window.saveCFSettings = saveCFSettings;

function saveAnalyticsSettings() {
  localStorage.setItem('lc_ga_id', document.getElementById('s-gaId').value);
  localStorage.setItem('lc_fb_pixel', document.getElementById('s-fbPixel').value);
  localStorage.setItem('lc_custom_head', document.getElementById('s-customHead').value);
  alert('✅ تم حفظ أكواد التتبع');
}
window.saveAnalyticsSettings = saveAnalyticsSettings;

function saveBrandSettings() {
  localStorage.setItem('lc_brand_name', document.getElementById('s-brandName').value);
  localStorage.setItem('lc_brand_color', document.getElementById('s-brandColor').value);
  localStorage.setItem('lc_logo_url', document.getElementById('s-logoUrl').value);
  alert('✅ تم حفظ إعدادات العلامة التجارية');
}
window.saveBrandSettings = saveBrandSettings;

async function testNetlifyToken() {
  const token = document.getElementById('s-netlifyToken').value.trim();
  if (!token) { showSettingsSaved('netlify-test-result', '⚠ أدخل التوكن أولاً'); return; }
  const div = document.getElementById('netlify-test-result');
  div.textContent = '⏳ جاري الاختبار...';
  div.style.color = 'var(--text-muted)';
  try {
    const res = await fetch('https://api.netlify.com/api/v1/user', {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    if (res.ok) {
      const user = await res.json();
      div.textContent = `✅ متصل! مرحباً ${user.full_name || user.email}`;
      div.style.color = 'var(--accent-3)';
    } else {
      div.textContent = '❌ توكن غير صحيح';
      div.style.color = 'var(--accent-2)';
    }
  } catch(e) {
    div.textContent = '❌ خطأ في الاتصال';
    div.style.color = 'var(--accent-2)';
  }
}
window.testNetlifyToken = testNetlifyToken;

function showSettingsSaved(id, msg) {
  const el = document.getElementById(id);
  if (el) { el.textContent = msg; el.style.color = 'var(--accent-3)'; }
}

// Export/Import
function exportAllData() {
  const data = {
    version: '1.0',
    exported: new Date().toISOString(),
    current: localStorage.getItem('lc_current'),
    published: localStorage.getItem('lc_published'),
    settings: {
      netlifyToken: localStorage.getItem('lc_netlify_token'),
      brandName: localStorage.getItem('lc_brand_name'),
    }
  };
  const blob = new Blob([JSON.stringify(data, null, 2)], {type:'application/json'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'landingcraft-backup.json';
  a.click();
}
window.exportAllData = exportAllData;

function importAllData(input) {
  const file = input.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    try {
      const data = JSON.parse(e.target.result);
      if (data.current) localStorage.setItem('lc_current', data.current);
      if (data.published) localStorage.setItem('lc_published', data.published);
      alert('✅ تم الاستيراد بنجاح!');
      loadDashboard();
    } catch(err) {
      alert('❌ ملف غير صحيح');
    }
  };
  reader.readAsText(file);
}
window.importAllData = importAllData;

function clearAllData() {
  if (!confirm('⚠ سيتم حذف كل البيانات. هل أنت متأكد؟')) return;
  ['lc_current','lc_published','lc_netlify_token','lc_cf_account','lc_cf_token'].forEach(k => localStorage.removeItem(k));
  alert('✅ تم مسح البيانات');
  loadDashboard();
}
window.clearAllData = clearAllData;

// Load saved settings
function loadSettings() {
  const token = localStorage.getItem('lc_netlify_token');
  if (token) document.getElementById('s-netlifyToken').value = token;
  const gaId = localStorage.getItem('lc_ga_id');
  if (gaId) document.getElementById('s-gaId').value = gaId;
  const brandName = localStorage.getItem('lc_brand_name');
  if (brandName) document.getElementById('s-brandName').value = brandName;
  const brandColor = localStorage.getItem('lc_brand_color');
  if (brandColor) document.getElementById('s-brandColor').value = brandColor;
}

// Check for template URL param
const urlParams = new URLSearchParams(window.location.search);
if (urlParams.get('tpl')) {
  // Redirect to builder with template
  window.location.href = `index.html?tpl=${urlParams.get('tpl')}`;
}

// Init
loadDashboard();
loadSettings();
