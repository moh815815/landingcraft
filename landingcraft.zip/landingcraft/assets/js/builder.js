/* =============================================
   LandingCraft — Builder Engine (Fixed)
   ============================================= */
'use strict';

// ---- State ----
const state = {
  elements: [],
  selectedId: null,
  undoStack: [],
  redoStack: [],
  pageSettings: {
    name: 'صفحتي الجديدة',
    background: '#ffffff',
    font: 'Cairo',
    primaryColor: '#6c63ff',
    width: '1200px'
  },
  dragSource: null,
  uploadedImages: []
};

let idCounter = 1;
const genId = () => `el_${Date.now()}_${idCounter++}`;

// ---- Splash ----
window.addEventListener('DOMContentLoaded', () => {
  setTimeout(() => {
    document.getElementById('splash').classList.add('hidden');
    init();
  }, 1600);
});

function init() {
  bindTopbar();
  bindElementsPanel();
  bindProps();
  bindPageSettings();
  bindPublishModal();
  bindImageModal();
  loadFromStorage();
  renderCanvas();
  // Handle ?tpl= param
  const p = new URLSearchParams(location.search).get('tpl');
  if (p && templates[p]) {
    state.elements = templates[p]();
    saveToStorage();
    renderCanvas();
  }
}

// ============================================================
//  TOP BAR
// ============================================================
function bindTopbar() {
  document.querySelectorAll('.view-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.view-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const cv = document.getElementById('canvas');
      cv.className = 'canvas-' + btn.dataset.view;
    });
  });

  document.getElementById('btnUndo').addEventListener('click', undo);
  document.getElementById('btnRedo').addEventListener('click', redo);
  document.getElementById('btnPreview').addEventListener('click', openPreview);
  document.getElementById('btnPublish').addEventListener('click', () => openModal('publishModal'));

  document.getElementById('pageName').addEventListener('input', e => {
    state.pageSettings.name = e.target.value;
    saveToStorage();
  });

  document.addEventListener('keydown', e => {
    const tag = document.activeElement.tagName;
    const typing = ['INPUT','TEXTAREA','SELECT'].includes(tag);
    if ((e.ctrlKey || e.metaKey) && e.key === 'z') { e.preventDefault(); undo(); }
    if ((e.ctrlKey || e.metaKey) && e.key === 'y') { e.preventDefault(); redo(); }
    if ((e.ctrlKey || e.metaKey) && e.key === 'd') { e.preventDefault(); duplicateSelected(); }
    if ((e.key === 'Delete' || e.key === 'Backspace') && state.selectedId && !typing) {
      e.preventDefault(); deleteSelected();
    }
    if (e.key === 'Escape') deselectAll();
  });
}

// ============================================================
//  ELEMENTS PANEL
// ============================================================
function bindElementsPanel() {
  // Category tabs
  document.querySelectorAll('.etab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.etab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      const cat = tab.dataset.cat;
      document.querySelectorAll('.elem-card').forEach(card => {
        card.style.display = card.dataset.cat === cat ? '' : 'none';
      });
    });
  });

  // Search
  document.getElementById('elemSearch').addEventListener('input', e => {
    const q = e.target.value.toLowerCase();
    document.querySelectorAll('.elem-card').forEach(card => {
      const label = card.querySelector('.elem-label').textContent.toLowerCase();
      if (q) {
        card.style.display = label.includes(q) ? '' : 'none';
      } else {
        // Restore active cat
        const activeCat = document.querySelector('.etab.active')?.dataset.cat || 'basic';
        card.style.display = card.dataset.cat === activeCat ? '' : 'none';
      }
    });
  });

  // Drag from panel
  document.querySelectorAll('.elem-card').forEach(card => {
    card.addEventListener('dragstart', e => {
      e.dataTransfer.setData('lc-type', card.dataset.type);
      e.dataTransfer.setData('lc-source', 'panel');
      e.dataTransfer.effectAllowed = 'copy';
      card.classList.add('dragging');
    });
    card.addEventListener('dragend', () => card.classList.remove('dragging'));
  });
}

// ============================================================
//  CANVAS
// ============================================================
function renderCanvas() {
  const canvas = document.getElementById('canvas');
  // Apply page settings
  canvas.style.background = state.pageSettings.background;
  canvas.style.fontFamily = `'${state.pageSettings.font}', sans-serif`;

  if (state.elements.length === 0) {
    canvas.innerHTML = `<div id="drop-zone" class="drop-zone">
      <div class="drop-hint">
        <div class="drop-icon">⬇</div>
        <p>اسحب العناصر هنا لبدء البناء</p>
        <p class="drop-sub">أو اختر قالباً جاهزاً من الشريط الجانبي</p>
      </div>
    </div>`;
    setupCanvasDrop(canvas);
    return;
  }

  canvas.innerHTML = '';
  state.elements.forEach((el, idx) => {
    const wrapper = createElementWrapper(el, idx);
    canvas.appendChild(wrapper);
  });
  setupCanvasDrop(canvas);
}

function createElementWrapper(el, idx) {
  const wrapper = document.createElement('div');
  wrapper.className = 'canvas-element' + (el.id === state.selectedId ? ' selected' : '');
  wrapper.dataset.id = el.id;

  // Controls bar
  const controls = document.createElement('div');
  controls.className = 'elem-controls';
  controls.innerHTML = `
    <span class="elem-drag-handle" title="سحب">⠿</span>
    <button data-action="select" title="تحرير">✏</button>
    <button data-action="dup" title="نسخ">⎘</button>
    <button data-action="up" title="أعلى">↑</button>
    <button data-action="down" title="أسفل">↓</button>
    <button data-action="del" title="حذف" class="del-btn">🗑</button>
  `;
  // Button clicks
  controls.querySelectorAll('button').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      const a = btn.dataset.action;
      if (a === 'select') selectElement(el.id);
      else if (a === 'dup') { duplicateElement(el.id); }
      else if (a === 'up') moveElementUp(el.id);
      else if (a === 'down') moveElementDown(el.id);
      else if (a === 'del') deleteElement(el.id);
    });
  });

  // Drag handle for reorder
  const handle = controls.querySelector('.elem-drag-handle');
  handle.setAttribute('draggable', 'true');
  handle.addEventListener('dragstart', e => {
    e.stopPropagation();
    state.dragSource = el.id;
    e.dataTransfer.setData('lc-reorder', el.id);
    e.dataTransfer.effectAllowed = 'move';
  });

  wrapper.appendChild(controls);

  // Content
  const content = document.createElement('div');
  content.innerHTML = renderElementHTML(el);
  wrapper.appendChild(content);

  // Drop target for reorder + new from panel
  wrapper.addEventListener('dragover', e => {
    e.preventDefault();
    e.stopPropagation();
    wrapper.classList.remove('drag-over-top', 'drag-over-bottom');
    const mid = wrapper.getBoundingClientRect().top + wrapper.offsetHeight / 2;
    wrapper.classList.add(e.clientY < mid ? 'drag-over-top' : 'drag-over-bottom');
  });
  wrapper.addEventListener('dragleave', () => {
    wrapper.classList.remove('drag-over-top', 'drag-over-bottom');
  });
  wrapper.addEventListener('drop', e => {
    e.preventDefault();
    e.stopPropagation();
    wrapper.classList.remove('drag-over-top', 'drag-over-bottom');

    const reorderId = e.dataTransfer.getData('lc-reorder');
    const newType  = e.dataTransfer.getData('lc-type');
    const source   = e.dataTransfer.getData('lc-source');
    const toIdx    = state.elements.findIndex(x => x.id === el.id);
    const mid      = wrapper.getBoundingClientRect().top + wrapper.offsetHeight / 2;
    const after    = e.clientY >= mid;

    if (reorderId && reorderId !== el.id) {
      pushUndo();
      const fromIdx = state.elements.findIndex(x => x.id === reorderId);
      const [moved] = state.elements.splice(fromIdx, 1);
      const newToIdx = state.elements.findIndex(x => x.id === el.id);
      state.elements.splice(after ? newToIdx + 1 : newToIdx, 0, moved);
      saveToStorage(); renderCanvas(); selectElement(reorderId);
    } else if (newType && source === 'panel') {
      pushUndo();
      const newEl = createElement(newType);
      state.elements.splice(after ? toIdx + 1 : toIdx, 0, newEl);
      saveToStorage(); renderCanvas(); selectElement(newEl.id);
    }
  });

  // Click to select
  wrapper.addEventListener('click', e => {
    if (!e.target.closest('.elem-controls')) {
      e.stopPropagation();
      selectElement(el.id);
    }
  });

  return wrapper;
}

function setupCanvasDrop(canvas) {
  canvas.addEventListener('dragover', e => { e.preventDefault(); });
  canvas.addEventListener('drop', e => {
    e.preventDefault();
    const type   = e.dataTransfer.getData('lc-type');
    const source = e.dataTransfer.getData('lc-source');
    // Only handle if dropped on canvas bg (not on a child wrapper)
    if (type && source === 'panel' && e.target === canvas) {
      pushUndo();
      const el = createElement(type);
      state.elements.push(el);
      saveToStorage(); renderCanvas(); selectElement(el.id);
    }
  });
  canvas.addEventListener('click', e => {
    if (e.target === canvas || e.target.closest('#drop-zone')) deselectAll();
  });
}

// ============================================================
//  ELEMENT DEFAULTS
// ============================================================
function createElement(type) {
  return { id: genId(), type, ...getDefaults(type) };
}

function getDefaults(type) {
  const adv = { customCSS: '', id: '', class: '', hideOnMobile: false };
  switch (type) {
    case 'heading':     return { content: { text: 'عنوان رئيسي جذاب', tag: 'h1' }, style: { fontSize: '2.5rem', color: '#1a1d28', fontWeight: '700', textAlign: 'center', padding: '16px 20px' }, advanced: adv };
    case 'paragraph':   return { content: { text: 'أضف نصك الوصفي هنا. اجعله واضحاً وجذاباً لزوار صفحتك.' }, style: { fontSize: '1rem', color: '#555555', textAlign: 'center', padding: '8px 20px', lineHeight: '1.7' }, advanced: adv };
    case 'button':      return { content: { text: 'ابدأ الآن مجاناً', link: '#', variant: 'primary', target: '_self' }, style: { textAlign: 'center', padding: '16px 20px' }, advanced: adv };
    case 'divider':     return { content: {}, style: { color: '#e0e0e0', margin: '16px 20px' }, advanced: adv };
    case 'spacer':      return { content: {}, style: { height: '40px' }, advanced: adv };
    case 'image':       return { content: { src: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=800', alt: 'صورة', width: '100%', link: '' }, style: { textAlign: 'center', padding: '16px 20px' }, advanced: adv };
    case 'video':       return { content: { url: 'https://www.youtube.com/embed/dQw4w9WgXcQ' }, style: { padding: '16px 40px' }, advanced: adv };
    case 'icon':        return { content: { icon: '⭐', size: '3rem' }, style: { textAlign: 'center', padding: '12px 20px' }, advanced: adv };
    case 'list':        return { content: { items: ['العنصر الأول', 'العنصر الثاني', 'العنصر الثالث'], listType: 'ul' }, style: { padding: '12px 40px', color: '#333333', fontSize: '1rem' }, advanced: adv };
    case 'columns2':    return { content: { cols: [[], []] }, style: { padding: '20px' }, advanced: adv };
    case 'columns3':    return { content: { cols: [[], [], []] }, style: { padding: '20px' }, advanced: adv };
    case 'hero':        return { content: { title: 'حوّل أفكارك إلى واقع', subtitle: 'أنشئ صفحات هبوط احترافية في دقائق وابدأ رحلة نجاحك الرقمي', btnText: 'ابدأ مجاناً', btnLink: '#' }, style: { background: 'linear-gradient(135deg,#6c63ff 0%,#ff6584 100%)', color: '#ffffff', padding: '100px 60px', textAlign: 'center' }, advanced: adv };
    case 'features':    return { content: { title: 'لماذا تختارنا؟', features: [{ icon: '⚡', title: 'سريع وفعال', desc: 'أداء عالي ووقت تحميل سريع' }, { icon: '🎨', title: 'تصميم احترافي', desc: 'قوالب مصممة بعناية تعكس هويتك' }, { icon: '📱', title: 'متجاوب بالكامل', desc: 'يعمل مثالياً على جميع الأجهزة' }] }, style: { padding: '60px 40px', background: '#ffffff', textAlign: 'center' }, advanced: adv };
    case 'pricing':     return { content: { title: 'خطط تناسب الجميع', plans: [{ name: 'مجاني', price: '0', period: 'شهرياً', features: ['5 صفحات', '1000 زيارة', 'دعم بريد'], featured: false }, { name: 'احترافي', price: '99', period: 'شهرياً', features: ['غير محدود', 'زيارات غير محدودة', 'دعم أولوية', 'نطاق مخصص'], featured: true }, { name: 'مؤسسي', price: '299', period: 'شهرياً', features: ['كل مميزات الاحترافي', 'API كامل', 'دعم 24/7'], featured: false }] }, style: { padding: '60px 40px', background: '#f9fafb', textAlign: 'center' }, advanced: adv };
    case 'testimonial': return { content: { title: 'ماذا يقول عملاؤنا', testimonials: [{ name: 'أحمد محمد', role: 'مدير تنفيذي', text: 'خدمة رائعة وفريق متميز. نتائج تجاوزت توقعاتنا.', avatar: '👨‍💼' }, { name: 'سارة علي', role: 'مسوّقة رقمية', text: 'سهولة في الاستخدام وتصميمات احترافية. أنصح به!', avatar: '👩‍💼' }, { name: 'خالد حسن', role: 'مطور ويب', text: 'الأفضل في السوق من حيث المميزات والسعر.', avatar: '👨‍💻' }] }, style: { padding: '60px 40px', background: '#ffffff' }, advanced: adv };
    case 'cta':         return { content: { title: 'جاهز للبدء؟', subtitle: 'انضم إلى آلاف العملاء الناجحين اليوم', btnText: 'ابدأ مجاناً', btnLink: '#' }, style: { padding: '80px 40px', textAlign: 'center', background: '#6c63ff', color: '#ffffff' }, advanced: adv };
    case 'navbar':      return { content: { brand: 'شعار علامتك', links: ['الرئيسية', 'المميزات', 'الأسعار', 'تواصل'] }, style: { background: '#ffffff', padding: '16px 40px' }, advanced: adv };
    case 'footer':      return { content: { brand: 'علامتك التجارية', tagline: 'نبني مستقبلك الرقمي', copyright: '© 2025 جميع الحقوق محفوظة' }, style: { background: '#1a1d28', color: '#aaaaaa', padding: '40px' }, advanced: adv };
    case 'counter':     return { content: { counters: [{ num: '10K+', label: 'عميل راضٍ' }, { num: '99%', label: 'رضا العملاء' }, { num: '50+', label: 'دولة' }, { num: '24/7', label: 'دعم فني' }] }, style: { padding: '60px 40px', background: '#f9fafb', textAlign: 'center' }, advanced: adv };
    case 'form':        return { content: { title: 'تواصل معنا', fields: ['الاسم الكامل', 'البريد الإلكتروني', 'الرسالة'], btnText: 'إرسال' }, style: { padding: '60px 40px', textAlign: 'center' }, advanced: adv };
    case 'input':       return { content: { placeholder: 'أدخل نصك هنا', label: 'حقل النص', inputType: 'text' }, style: { padding: '8px 20px' }, advanced: adv };
    case 'newsletter':  return { content: { title: 'اشترك في نشرتنا البريدية', subtitle: 'احصل على آخر التحديثات والعروض الحصرية', placeholder: 'أدخل بريدك الإلكتروني', btnText: 'اشترك' }, style: { padding: '60px 40px', textAlign: 'center', background: '#f9fafb' }, advanced: adv };
    case 'gallery':     return { content: { images: ['https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400', 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=400', 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400'] }, style: { padding: '20px' }, advanced: adv };
    default:            return { content: {}, style: {}, advanced: adv };
  }
}

// ============================================================
//  RENDER ELEMENT HTML
// ============================================================
function renderElementHTML(el) {
  const s  = el.style  || {};
  const c  = el.content || {};
  const pc = state.pageSettings.primaryColor;

  // Build inline CSS string
  const cssStr = objToCSS(s);

  switch (el.type) {
    case 'heading':
      return `<${c.tag||'h1'} class="lc-heading" style="${cssStr}">${esc(c.text||'')}</${c.tag||'h1'}>`;

    case 'paragraph':
      return `<p class="lc-paragraph" style="${cssStr}">${esc(c.text||'')}</p>`;

    case 'button': {
      const bg  = c.variant === 'secondary' ? 'transparent' : pc;
      const col = c.variant === 'secondary' ? pc : '#fff';
      const brd = c.variant === 'secondary' ? `border:2px solid ${pc};` : '';
      return `<div class="lc-button-wrap" style="text-align:${s.textAlign||'center'};padding:${s.padding||'16px 20px'}">
        <a href="${c.link||'#'}" class="lc-btn" target="${c.target||'_self'}"
           style="background:${bg};color:${col};${brd}">${esc(c.text||'زر')}</a>
      </div>`;
    }

    case 'divider':
      return `<hr style="border:none;height:1px;background:${s.color||'#e0e0e0'};margin:${s.margin||'16px 20px'}" />`;

    case 'spacer':
      return `<div style="height:${s.height||'40px'};display:block"></div>`;

    case 'image':
      return `<div style="${cssStr}"><img src="${c.src||''}" alt="${esc(c.alt||'')}" style="max-width:100%;width:${c.width||'100%'};border-radius:8px;display:block;margin:0 auto" /></div>`;

    case 'video':
      return `<div style="${cssStr}"><div style="position:relative;padding-bottom:56.25%;height:0;overflow:hidden;border-radius:12px">
        <iframe src="${c.url||''}" frameborder="0" allowfullscreen style="position:absolute;inset:0;width:100%;height:100%"></iframe>
      </div></div>`;

    case 'icon':
      return `<div style="${cssStr};font-size:${c.size||'3rem'}">${c.icon||'⭐'}</div>`;

    case 'list':
      return `<${c.listType||'ul'} style="${cssStr};padding-right:20px;line-height:2">${(c.items||[]).map(i => `<li>${esc(i)}</li>`).join('')}</${c.listType||'ul'}>`;

    case 'columns2':
      return `<div style="${cssStr};display:grid;grid-template-columns:1fr 1fr;gap:20px">
        <div style="padding:12px;border:1px dashed #ccc;text-align:center;color:#aaa;min-height:60px">عمود 1</div>
        <div style="padding:12px;border:1px dashed #ccc;text-align:center;color:#aaa;min-height:60px">عمود 2</div>
      </div>`;

    case 'columns3':
      return `<div style="${cssStr};display:grid;grid-template-columns:1fr 1fr 1fr;gap:20px">
        <div style="padding:12px;border:1px dashed #ccc;text-align:center;color:#aaa;min-height:60px">عمود 1</div>
        <div style="padding:12px;border:1px dashed #ccc;text-align:center;color:#aaa;min-height:60px">عمود 2</div>
        <div style="padding:12px;border:1px dashed #ccc;text-align:center;color:#aaa;min-height:60px">عمود 3</div>
      </div>`;

    case 'hero':
      return `<div style="${cssStr};min-height:80vh;display:flex;align-items:center;justify-content:center;text-align:${s.textAlign||'center'}">
        <div>
          <h1 style="font-size:3rem;font-weight:900;margin-bottom:16px;line-height:1.2;color:${s.color||'#fff'}">${esc(c.title||'')}</h1>
          <p style="font-size:1.2rem;opacity:.9;max-width:600px;margin:0 auto 32px;color:${s.color||'#fff'}">${esc(c.subtitle||'')}</p>
          <a href="${c.btnLink||'#'}" style="display:inline-block;padding:16px 40px;background:rgba(255,255,255,.2);color:#fff;border:2px solid rgba(255,255,255,.6);border-radius:8px;font-weight:700;font-size:1.1rem;text-decoration:none;backdrop-filter:blur(10px)">${esc(c.btnText||'ابدأ')}</a>
        </div>
      </div>`;

    case 'features':
      return `<div style="${cssStr}">
        <h2 style="font-size:2rem;font-weight:800;text-align:center;margin-bottom:40px">${esc(c.title||'')}</h2>
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:24px">
          ${(c.features||[]).map(f => `<div style="padding:24px;border-radius:12px;border:1px solid #e5e7eb;text-align:center">
            <div style="font-size:2rem;margin-bottom:12px">${f.icon||''}</div>
            <h3 style="font-weight:700;margin-bottom:8px">${esc(f.title||'')}</h3>
            <p style="color:#666;line-height:1.6;font-size:.9rem">${esc(f.desc||'')}</p>
          </div>`).join('')}
        </div>
      </div>`;

    case 'pricing':
      return `<div style="${cssStr}">
        <h2 style="font-size:2rem;font-weight:800;text-align:center;margin-bottom:40px">${esc(c.title||'')}</h2>
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:20px">
          ${(c.plans||[]).map(p => `<div style="padding:32px 24px;border-radius:16px;border:1px solid ${p.featured?pc:'#e5e7eb'};background:${p.featured?pc:'#fff'};color:${p.featured?'#fff':'#333'};text-align:center">
            <h3 style="font-size:1.1rem;margin-bottom:16px">${esc(p.name||'')}</h3>
            <div style="font-size:2.5rem;font-weight:900;margin-bottom:4px">${esc(p.price||'0')} <small style="font-size:1rem">ر.س</small></div>
            <div style="opacity:.7;margin-bottom:20px;font-size:.85rem">${esc(p.period||'')}</div>
            <ul style="list-style:none;margin-bottom:24px;text-align:right">${(p.features||[]).map(f => `<li style="padding:6px 0;border-bottom:1px solid ${p.featured?'rgba(255,255,255,.2)':'#f0f0f0'}">✓ ${esc(f)}</li>`).join('')}</ul>
            <a href="#" style="display:block;padding:12px;border-radius:8px;background:${p.featured?'#fff':pc};color:${p.featured?pc:'#fff'};text-decoration:none;font-weight:700">اختر الخطة</a>
          </div>`).join('')}
        </div>
      </div>`;

    case 'testimonial':
      return `<div style="${cssStr}">
        <h2 style="font-size:2rem;font-weight:800;text-align:center;margin-bottom:40px">${esc(c.title||'')}</h2>
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:20px">
          ${(c.testimonials||[]).map(t => `<div style="padding:24px;border-radius:12px;background:#f9fafb">
            <div style="font-size:2rem;margin-bottom:12px">${t.avatar||'👤'}</div>
            <p style="line-height:1.6;color:#555;margin-bottom:16px">"${esc(t.text||'')}"</p>
            <div style="font-weight:700">${esc(t.name||'')}</div>
            <div style="color:#999;font-size:.85rem">${esc(t.role||'')}</div>
          </div>`).join('')}
        </div>
      </div>`;

    case 'cta':
      return `<div style="${cssStr}">
        <h2 style="font-size:2.2rem;font-weight:900;margin-bottom:12px">${esc(c.title||'')}</h2>
        <p style="opacity:.85;margin-bottom:32px;font-size:1.1rem">${esc(c.subtitle||'')}</p>
        <a href="${c.btnLink||'#'}" style="display:inline-block;padding:16px 40px;background:rgba(255,255,255,.2);color:#fff;border:2px solid rgba(255,255,255,.6);border-radius:8px;font-weight:700;font-size:1.1rem;text-decoration:none">${esc(c.btnText||'ابدأ')}</a>
      </div>`;

    case 'navbar':
      return `<nav style="${cssStr};display:flex;align-items:center;justify-content:space-between">
        <div style="font-weight:800;font-size:1.2rem">${esc(c.brand||'الشعار')}</div>
        <ul style="display:flex;gap:20px;list-style:none;margin:0;padding:0">
          ${(c.links||[]).map(l => `<li><a href="#" style="text-decoration:none;color:inherit;font-weight:500">${esc(l)}</a></li>`).join('')}
        </ul>
      </nav>`;

    case 'footer':
      return `<footer style="${cssStr};text-align:center">
        <div style="font-weight:800;font-size:1.2rem;color:#fff;margin-bottom:8px">${esc(c.brand||'')}</div>
        <div style="margin-bottom:16px">${esc(c.tagline||'')}</div>
        <div style="font-size:.85rem;opacity:.5">${esc(c.copyright||'')}</div>
      </footer>`;

    case 'counter':
      return `<div style="${cssStr}">
        <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:20px;text-align:center">
          ${(c.counters||[]).map(ct => `<div>
            <div style="font-size:2.5rem;font-weight:900;color:${pc}">${esc(ct.num||'')}</div>
            <div style="color:#666;margin-top:4px">${esc(ct.label||'')}</div>
          </div>`).join('')}
        </div>
      </div>`;

    case 'form':
      return `<div style="${cssStr}">
        <h3 style="font-size:1.5rem;font-weight:800;margin-bottom:24px">${esc(c.title||'')}</h3>
        <div style="max-width:500px;margin:0 auto">
          ${(c.fields||[]).map((f, i) => i === (c.fields.length - 1) && f.includes('رسالة')
            ? `<textarea placeholder="${esc(f)}" rows="4" style="width:100%;padding:12px 16px;margin-bottom:12px;border:1px solid #e5e7eb;border-radius:8px;font-size:.95rem;font-family:inherit;resize:vertical"></textarea>`
            : `<input type="text" placeholder="${esc(f)}" style="width:100%;padding:12px 16px;margin-bottom:12px;border:1px solid #e5e7eb;border-radius:8px;font-size:.95rem;font-family:inherit" />`
          ).join('')}
          <button style="width:100%;padding:14px;background:${pc};color:#fff;border:none;border-radius:8px;font-weight:700;font-size:1rem;cursor:pointer;font-family:inherit">${esc(c.btnText||'إرسال')}</button>
        </div>
      </div>`;

    case 'input':
      return `<div style="${cssStr}">
        <label style="display:block;margin-bottom:6px;font-weight:600;font-size:.9rem">${esc(c.label||'')}</label>
        <input type="${c.inputType||'text'}" placeholder="${esc(c.placeholder||'')}" style="width:100%;max-width:400px;padding:10px 14px;border:1px solid #e5e7eb;border-radius:8px;font-family:inherit" />
      </div>`;

    case 'newsletter':
      return `<div style="${cssStr}">
        <h3 style="font-size:1.5rem;font-weight:800;margin-bottom:8px">${esc(c.title||'')}</h3>
        <p style="color:#666;margin-bottom:20px">${esc(c.subtitle||'')}</p>
        <div style="display:flex;gap:8px;max-width:400px;margin:0 auto">
          <input type="email" placeholder="${esc(c.placeholder||'بريدك الإلكتروني')}" style="flex:1;padding:12px 16px;border:1px solid #e5e7eb;border-radius:8px;font-family:inherit" />
          <button style="padding:12px 20px;background:${pc};color:#fff;border:none;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;white-space:nowrap">${esc(c.btnText||'اشترك')}</button>
        </div>
      </div>`;

    case 'gallery':
      return `<div style="${cssStr}">
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px">
          ${(c.images||[]).map(img => `<img src="${img}" alt="" style="width:100%;border-radius:8px;aspect-ratio:1;object-fit:cover" />`).join('')}
        </div>
      </div>`;

    default:
      return `<div style="padding:20px;border:2px dashed #ccc;text-align:center;color:#999;font-size:.9rem">عنصر: ${el.type}</div>`;
  }
}

function objToCSS(obj) {
  return Object.entries(obj).map(([k, v]) => `${camelToKebab(k)}:${v}`).join(';');
}

function camelToKebab(s) {
  return s.replace(/([A-Z])/g, '-$1').toLowerCase();
}

function esc(str) {
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ============================================================
//  SELECTION & PROPERTIES
// ============================================================
function selectElement(id) {
  state.selectedId = id;
  renderCanvas();
  showProps(id);
}

function deselectAll() {
  state.selectedId = null;
  renderCanvas();
  document.getElementById('no-selection').style.display = '';
  document.getElementById('props-content').style.display = 'none';
}

function showProps(id) {
  const el = state.elements.find(e => e.id === id);
  if (!el) return;
  document.getElementById('no-selection').style.display = 'none';
  document.getElementById('props-content').style.display = '';
  buildStyleTab(el);
  buildContentTab(el);

  // Advanced tab
  document.getElementById('customCSS').value  = el.advanced?.customCSS || '';
  document.getElementById('elemId').value      = el.advanced?.id || '';
  document.getElementById('elemClass').value   = el.advanced?.class || '';
  document.getElementById('hideOnMobile').checked = el.advanced?.hideOnMobile || false;

  document.getElementById('customCSS').oninput  = () => { el.advanced.customCSS = document.getElementById('customCSS').value; saveToStorage(); };
  document.getElementById('elemId').oninput     = () => { el.advanced.id = document.getElementById('elemId').value; saveToStorage(); };
  document.getElementById('elemClass').oninput  = () => { el.advanced.class = document.getElementById('elemClass').value; saveToStorage(); };
  document.getElementById('hideOnMobile').onchange = function () { el.advanced.hideOnMobile = this.checked; saveToStorage(); };

  // Action buttons
  document.getElementById('btnDelete').onclick    = () => deleteElement(id);
  document.getElementById('btnDuplicate').onclick = () => duplicateElement(id);
  document.getElementById('btnMoveUp').onclick    = () => moveElementUp(id);
  document.getElementById('btnMoveDown').onclick  = () => moveElementDown(id);
}

// ---- Style Tab ----
function buildStyleTab(el) {
  if (!el) return;
  const s   = el.style || {};
  const id  = el.id;
  const panel = document.getElementById('ptab-style');

  panel.innerHTML = `
    ${colorField('لون النص', id, 'color', s.color||'#333333')}
    ${colorField('لون الخلفية', id, 'background', (s.background && s.background.startsWith('#')) ? s.background : '#ffffff')}
    <div class="prop-group"><label>حجم الخط</label>
      <div class="range-row">
        <input type="range" id="fs_range_${id}" min="10" max="96" value="${parseInt(s.fontSize)||16}" />
        <input type="number" id="fs_num_${id}" value="${parseInt(s.fontSize)||16}" min="10" max="96" style="width:60px" />
      </div>
    </div>
    <div class="prop-group"><label>محاذاة النص</label>
      <div class="align-row">
        ${['right','center','left','justify'].map(a =>
          `<button class="align-btn${s.textAlign===a?' active':''}" data-align="${a}" data-elid="${id}">${a==='right'?'⬛':a==='center'?'≡':a==='left'?'☰':'⊞'}</button>`
        ).join('')}
      </div>
    </div>
    <div class="prop-group"><label>سماكة الخط</label>
      <select id="fw_${id}">
        ${[300,400,500,600,700,800,900].map(w => `<option value="${w}"${parseInt(s.fontWeight)===w?' selected':''}>${w}</option>`).join('')}
      </select>
    </div>
    <div class="prop-group"><label>حشو (Padding)</label>
      <input type="text" id="pad_${id}" value="${s.padding||''}" placeholder="16px 20px" />
    </div>
    <div class="prop-group"><label>هامش (Margin)</label>
      <input type="text" id="mar_${id}" value="${s.margin||''}" placeholder="0 0 20px" />
    </div>
    <div class="prop-group"><label>الحدود</label>
      <input type="text" id="brd_${id}" value="${s.border||''}" placeholder="1px solid #e0e0e0" />
    </div>
    <div class="prop-group"><label>تدوير الحواف</label>
      <input type="text" id="br_${id}" value="${s.borderRadius||''}" placeholder="8px" />
    </div>
    <div class="prop-group"><label>شفافية (0-1)</label>
      <input type="number" id="op_${id}" step=".1" min="0" max="1" value="${s.opacity !== undefined ? s.opacity : 1}" />
    </div>
  `;

  // Bind font size
  const rangeEl = document.getElementById(`fs_range_${id}`);
  const numEl   = document.getElementById(`fs_num_${id}`);
  const syncFS = val => {
    rangeEl.value = val; numEl.value = val;
    updateStyle(id, 'fontSize', val + 'px');
  };
  rangeEl.addEventListener('input', () => syncFS(rangeEl.value));
  numEl.addEventListener('input',   () => syncFS(numEl.value));

  // Align buttons
  panel.querySelectorAll('.align-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      updateStyle(id, 'textAlign', btn.dataset.align);
      buildStyleTab(state.elements.find(e => e.id === id));
    });
  });

  // Other fields
  document.getElementById(`fw_${id}`).addEventListener('change', e => updateStyle(id, 'fontWeight', e.target.value));
  document.getElementById(`pad_${id}`).addEventListener('input', e => updateStyle(id, 'padding', e.target.value));
  document.getElementById(`mar_${id}`).addEventListener('input', e => updateStyle(id, 'margin', e.target.value));
  document.getElementById(`brd_${id}`).addEventListener('input', e => updateStyle(id, 'border', e.target.value));
  document.getElementById(`br_${id}`).addEventListener('input',  e => updateStyle(id, 'borderRadius', e.target.value));
  document.getElementById(`op_${id}`).addEventListener('input',  e => updateStyle(id, 'opacity', e.target.value));
}

function colorField(label, elId, prop, val) {
  const safe = /^#[0-9a-fA-F]{6}$/.test(val) ? val : '#ffffff';
  const uid  = `c_${prop}_${elId}`;
  // We'll bind via event delegation after innerHTML set
  return `<div class="prop-group"><label>${label}</label>
    <div class="color-row">
      <input type="color" id="${uid}_picker" value="${safe}" data-elid="${elId}" data-prop="${prop}" />
      <input type="text"  id="${uid}_text"   value="${val||''}" class="color-text" data-elid="${elId}" data-prop="${prop}" placeholder="${label}" />
    </div>
  </div>`;
}

// After panel.innerHTML is set, attach color listeners
document.addEventListener('input', e => {
  const t = e.target;
  if (!t.dataset.elid || !t.dataset.prop) return;
  const elId = t.dataset.elid;
  const prop = t.dataset.prop;
  const val  = t.value;
  const uid  = `c_${prop}_${elId}`;
  if (t.type === 'color') {
    const txt = document.getElementById(`${uid}_text`);
    if (txt) txt.value = val;
    updateStyle(elId, prop, val);
  } else if (t.classList.contains('color-text')) {
    const picker = document.getElementById(`${uid}_picker`);
    if (/^#[0-9a-fA-F]{6}$/.test(val) && picker) picker.value = val;
    updateStyle(elId, prop, val);
  }
});

function updateStyle(id, key, value) {
  const el = state.elements.find(e => e.id === id);
  if (!el) return;
  el.style[key] = value;
  // Live-update just the element's rendered content without full re-render
  const wrapper = document.querySelector(`.canvas-element[data-id="${id}"]`);
  if (wrapper) {
    const content = wrapper.children[1];
    if (content) content.innerHTML = renderElementHTML(el);
  }
  saveToStorage();
}

// ---- Content Tab ----
function buildContentTab(el) {
  const c     = el.content || {};
  const panel = document.getElementById('ptab-content');
  let rows    = '';

  const inp  = (label, key, val) => `<div class="prop-group"><label>${label}</label><input type="text" data-cid="${el.id}" data-key="${key}" value="${esc(val||'')}" /></div>`;
  const area = (label, key, val) => `<div class="prop-group"><label>${label}</label><textarea rows="4" data-cid="${el.id}" data-key="${key}">${esc(val||'')}</textarea></div>`;
  const sel  = (label, key, opts, cur) => `<div class="prop-group"><label>${label}</label><select data-cid="${el.id}" data-key="${key}">${opts.map(([v,l])=>`<option value="${v}"${cur===v?' selected':''}>${l}</option>`).join('')}</select></div>`;

  switch (el.type) {
    case 'heading':
      rows = inp('النص', 'text', c.text) + sel('مستوى العنوان', 'tag', [['h1','H1'],['h2','H2'],['h3','H3'],['h4','H4'],['h5','H5'],['h6','H6']], c.tag||'h1');
      break;
    case 'paragraph':
      rows = area('النص', 'text', c.text);
      break;
    case 'button':
      rows = inp('نص الزر','text',c.text) + inp('الرابط','link',c.link)
           + sel('النوع','variant',[['primary','أساسي'],['secondary','ثانوي']],c.variant||'primary')
           + sel('فتح في','target',[['_self','نفس التبويب'],['_blank','تبويب جديد']],c.target||'_self');
      break;
    case 'image':
      rows = inp('رابط الصورة','src',c.src) + inp('نص بديل','alt',c.alt) + inp('العرض','width',c.width||'100%')
           + `<button class="btn-outline" id="openImgModal" style="width:100%;margin-top:4px">📂 رفع صورة</button>`;
      break;
    case 'video':
      rows = inp('رابط YouTube Embed','url',c.url) + `<small style="color:var(--text-dim);font-size:.78rem">مثال: https://www.youtube.com/embed/VIDEO_ID</small>`;
      break;
    case 'hero':
      rows = inp('العنوان','title',c.title) + area('النص الفرعي','subtitle',c.subtitle) + inp('نص الزر','btnText',c.btnText) + inp('رابط الزر','btnLink',c.btnLink);
      break;
    case 'cta':
      rows = inp('العنوان','title',c.title) + inp('النص الفرعي','subtitle',c.subtitle) + inp('نص الزر','btnText',c.btnText) + inp('رابط الزر','btnLink',c.btnLink);
      break;
    case 'navbar':
      rows = inp('الشعار/الاسم','brand',c.brand)
           + `<div class="prop-group"><label>الروابط (سطر لكل رابط)</label><textarea rows="5" data-cid="${el.id}" data-key="links_arr">${(c.links||[]).join('\n')}</textarea></div>`;
      break;
    case 'footer':
      rows = inp('اسم العلامة','brand',c.brand) + inp('الوصف','tagline',c.tagline) + inp('حقوق النشر','copyright',c.copyright);
      break;
    case 'list':
      rows = sel('نوع القائمة','listType',[['ul','نقاط (ul)'],['ol','مرقمة (ol)']],c.listType||'ul')
           + `<div class="prop-group"><label>العناصر (سطر لكل عنصر)</label><textarea rows="6" data-cid="${el.id}" data-key="items_arr">${(c.items||[]).join('\n')}</textarea></div>`;
      break;
    case 'newsletter':
      rows = inp('العنوان','title',c.title) + inp('النص','subtitle',c.subtitle) + inp('نص الزر','btnText',c.btnText) + inp('placeholder','placeholder',c.placeholder);
      break;
    case 'spacer':
      rows = `<div class="prop-group"><label>الارتفاع</label><input type="text" data-sid="${el.id}" data-skey="height" value="${el.style.height||'40px'}" /></div>`;
      break;
    case 'icon':
      rows = inp('الأيقونة (emoji)','icon',c.icon) + inp('الحجم','size',c.size||'3rem');
      break;
    case 'form':
      rows = inp('العنوان','title',c.title) + inp('نص الزر','btnText',c.btnText)
           + `<div class="prop-group"><label>الحقول (سطر لكل حقل)</label><textarea rows="5" data-cid="${el.id}" data-key="fields_arr">${(c.fields||[]).join('\n')}</textarea></div>`;
      break;
    default:
      rows = '<p style="color:var(--text-dim);font-size:.85rem;padding:8px">لا توجد إعدادات لهذا العنصر</p>';
  }
  panel.innerHTML = rows;

  // Bind all content inputs
  panel.querySelectorAll('[data-cid]').forEach(input => {
    const cid = input.dataset.cid;
    const key = input.dataset.key;
    const ev  = input.tagName === 'SELECT' ? 'change' : 'input';
    input.addEventListener(ev, () => {
      const el2 = state.elements.find(e => e.id === cid);
      if (!el2) return;
      if (key === 'links_arr') {
        el2.content.links = input.value.split('\n').map(s => s.trim()).filter(Boolean);
      } else if (key === 'items_arr') {
        el2.content.items = input.value.split('\n').map(s => s.trim()).filter(Boolean);
      } else if (key === 'fields_arr') {
        el2.content.fields = input.value.split('\n').map(s => s.trim()).filter(Boolean);
      } else {
        el2.content[key] = input.value;
      }
      // Live update
      const wrapper = document.querySelector(`.canvas-element[data-id="${cid}"]`);
      if (wrapper) {
        const content = wrapper.children[1];
        if (content) content.innerHTML = renderElementHTML(el2);
      }
      saveToStorage();
    });
  });

  // Style key bindings for spacer
  panel.querySelectorAll('[data-sid]').forEach(input => {
    input.addEventListener('input', () => {
      const el2 = state.elements.find(e => e.id === input.dataset.sid);
      if (!el2) return;
      el2.style[input.dataset.skey] = input.value;
      const wrapper = document.querySelector(`.canvas-element[data-id="${input.dataset.sid}"]`);
      if (wrapper && wrapper.children[1]) wrapper.children[1].innerHTML = renderElementHTML(el2);
      saveToStorage();
    });
  });

  // Image modal button
  const imgBtn = document.getElementById('openImgModal');
  if (imgBtn) imgBtn.addEventListener('click', () => openModal('imageModal'));
}

// ============================================================
//  PROPS PANEL TABS
// ============================================================
function bindProps() {
  document.querySelectorAll('.ptab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.ptab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.ptab-content').forEach(c => c.classList.remove('active'));
      tab.classList.add('active');
      document.getElementById('ptab-' + tab.dataset.ptab).classList.add('active');
    });
  });
}

// ============================================================
//  PAGE SETTINGS
// ============================================================
function bindPageSettings() {
  document.getElementById('pageBackground').addEventListener('input', e => {
    state.pageSettings.background = e.target.value;
    document.getElementById('canvas').style.background = e.target.value;
    saveToStorage();
  });
  document.getElementById('pageFont').addEventListener('change', e => {
    state.pageSettings.font = e.target.value;
    document.getElementById('canvas').style.fontFamily = `'${e.target.value}', sans-serif`;
    saveToStorage();
  });
  document.getElementById('primaryColor').addEventListener('input', e => {
    state.pageSettings.primaryColor = e.target.value;
    renderCanvas();
    if (state.selectedId) {
      const el = state.elements.find(x => x.id === state.selectedId);
      if (el) { showProps(state.selectedId); }
    }
    saveToStorage();
  });
  document.getElementById('pageWidth').addEventListener('change', e => {
    document.getElementById('canvas').style.maxWidth = e.target.value;
  });
}

// ============================================================
//  ELEMENT OPERATIONS
// ============================================================
function deleteElement(id) {
  pushUndo();
  state.elements = state.elements.filter(e => e.id !== id);
  if (state.selectedId === id) state.selectedId = null;
  saveToStorage(); renderCanvas(); deselectAll();
}

function deleteSelected() { if (state.selectedId) deleteElement(state.selectedId); }

function duplicateElement(id) {
  pushUndo();
  const idx = state.elements.findIndex(e => e.id === id);
  if (idx < 0) return;
  const clone    = JSON.parse(JSON.stringify(state.elements[idx]));
  clone.id       = genId();
  state.elements.splice(idx + 1, 0, clone);
  saveToStorage(); renderCanvas(); selectElement(clone.id);
}

function duplicateSelected() { if (state.selectedId) duplicateElement(state.selectedId); }

function moveElementUp(id) {
  pushUndo();
  const idx = state.elements.findIndex(e => e.id === id);
  if (idx <= 0) return;
  [state.elements[idx], state.elements[idx - 1]] = [state.elements[idx - 1], state.elements[idx]];
  saveToStorage(); renderCanvas(); selectElement(id);
}

function moveElementDown(id) {
  pushUndo();
  const idx = state.elements.findIndex(e => e.id === id);
  if (idx >= state.elements.length - 1) return;
  [state.elements[idx], state.elements[idx + 1]] = [state.elements[idx + 1], state.elements[idx]];
  saveToStorage(); renderCanvas(); selectElement(id);
}

// ============================================================
//  UNDO / REDO
// ============================================================
function pushUndo() {
  state.undoStack.push(JSON.stringify(state.elements));
  if (state.undoStack.length > 50) state.undoStack.shift();
  state.redoStack = [];
}

function undo() {
  if (!state.undoStack.length) return;
  state.redoStack.push(JSON.stringify(state.elements));
  state.elements = JSON.parse(state.undoStack.pop());
  saveToStorage(); renderCanvas(); deselectAll();
}

function redo() {
  if (!state.redoStack.length) return;
  state.undoStack.push(JSON.stringify(state.elements));
  state.elements = JSON.parse(state.redoStack.pop());
  saveToStorage(); renderCanvas(); deselectAll();
}

// ============================================================
//  STORAGE
// ============================================================
function saveToStorage() {
  localStorage.setItem('lc_current', JSON.stringify({ elements: state.elements, pageSettings: state.pageSettings }));
}

function loadFromStorage() {
  try {
    const raw  = localStorage.getItem('lc_current');
    if (!raw) return;
    const data = JSON.parse(raw);
    state.elements = data.elements || [];
    if (data.pageSettings) Object.assign(state.pageSettings, data.pageSettings);
    document.getElementById('pageName').value       = state.pageSettings.name        || 'صفحتي الجديدة';
    document.getElementById('pageBackground').value = state.pageSettings.background  || '#ffffff';
    document.getElementById('pageFont').value       = state.pageSettings.font        || 'Cairo';
    document.getElementById('primaryColor').value   = state.pageSettings.primaryColor|| '#6c63ff';
  } catch (e) { console.warn('loadFromStorage error', e); }
}

// ============================================================
//  PREVIEW
// ============================================================
function openPreview() {
  const frame = document.getElementById('previewFrame');
  frame.srcdoc = generateHTML();
  openModal('previewModal');
}

// ============================================================
//  HTML GENERATION
// ============================================================
function generateHTML() {
  const s    = state.pageSettings;
  const body = state.elements.map(el => {
    const adv  = el.advanced || {};
    const id   = adv.id    ? ` id="${adv.id}"`      : '';
    const cls  = adv.class ? ` class="${adv.class}"`: '';
    const hide = adv.hideOnMobile ? ' data-hide-mobile="true"' : '';
    let html   = renderElementHTML(el);
    return `<div${id}${cls}${hide}>${html}</div>`;
  }).join('\n');

  return `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>${s.name||'صفحة الهبوط'}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=${encodeURIComponent(s.font||'Cairo')}:wght@300;400;600;700;900&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'${s.font||'Cairo'}',sans-serif;background:${s.background||'#fff'};direction:rtl;color:#333}
a{text-decoration:none;color:inherit}
img{max-width:100%}
.lc-btn{display:inline-block;padding:14px 36px;border-radius:8px;font-weight:700;font-size:.95rem;cursor:pointer;border:none;font-family:inherit;transition:all .2s;text-decoration:none}
.lc-btn:hover{transform:translateY(-2px);box-shadow:0 8px 20px rgba(0,0,0,.2)}
@media(max-width:768px){
  [style*="grid-template-columns:repeat(3"],[style*="grid-template-columns:1fr 1fr 1fr"]{grid-template-columns:1fr!important}
  [style*="grid-template-columns:1fr 1fr"]{grid-template-columns:1fr!important}
  [style*="grid-template-columns:repeat(4"]{grid-template-columns:1fr 1fr!important}
  [style*="min-height:80vh"]{padding:60px 20px!important}
  [data-hide-mobile="true"]{display:none!important}
  nav ul{display:none}
}
</style>
</head>
<body>
${body}
<script>
(function(){
  // Counter animation
  document.querySelectorAll('[style*="font-size:2.5rem"][style*="font-weight:900"]').forEach(function(el){
    var m=el.textContent.match(/([0-9]+)/);
    if(!m)return;
    var target=parseInt(m[1]),cur=0,step=Math.ceil(target/60);
    var prefix=el.textContent.split(m[1])[0];
    var suffix=el.textContent.split(m[1])[1]||'';
    var t=setInterval(function(){cur=Math.min(cur+step,target);el.textContent=prefix+cur+suffix;if(cur>=target)clearInterval(t);},16);
  });
  // Form submit
  document.querySelectorAll('button').forEach(function(btn){
    if(btn.closest('form')||btn.closest('[style*="max-width:500px"]')||btn.closest('[style*="max-width:400px"]')){
      btn.addEventListener('click',function(e){
        e.preventDefault();
        var inputs=btn.parentElement.querySelectorAll('input,textarea');
        var filled=true;
        inputs.forEach(function(i){if(!i.value.trim())filled=false;});
        if(filled) alert('شكراً! تم إرسال البيانات بنجاح ✅');
        else alert('⚠ الرجاء ملء جميع الحقول');
      });
    }
  });
})();
<\/script>
</body>
</html>`;
}

// ============================================================
//  DOWNLOAD HTML
// ============================================================
function downloadHTML() {
  const html = generateHTML();
  const a    = Object.assign(document.createElement('a'), {
    href:     URL.createObjectURL(new Blob([html], { type: 'text/html' })),
    download: (state.pageSettings.name || 'landing-page').replace(/\s+/g, '-') + '.html'
  });
  a.click();
}
window.downloadHTML = downloadHTML;

// ============================================================
//  PUBLISH MODAL TABS
// ============================================================
function bindPublishModal() {
  document.querySelectorAll('.publish-opt').forEach(opt => {
    opt.addEventListener('click', () => {
      document.querySelectorAll('.publish-opt').forEach(o => o.classList.remove('active'));
      opt.classList.add('active');
      ['netlify','cloudflare','download'].forEach(t => {
        document.getElementById(t + '-section').style.display = 'none';
      });
      document.getElementById(opt.dataset.target + '-section').style.display = '';
      document.getElementById('publish-result').style.display = 'none';
    });
  });
  // Bind deploy buttons
  const netlifyBtn = document.getElementById('btnNetlifyDeploy');
  if (netlifyBtn) netlifyBtn.addEventListener('click', deployToNetlify);
  const dlBtn = document.getElementById('btnDownload');
  if (dlBtn) dlBtn.addEventListener('click', downloadHTML);
  const cfBtn = document.getElementById('btnCFDeploy');
  if (cfBtn) cfBtn.addEventListener('click', deployToCloudflare);
}

// ---- Netlify Deploy ----
async function deployToNetlify() {
  const token    = document.getElementById('netlifyToken').value.trim();
  const siteName = document.getElementById('netlifyName').value.trim().toLowerCase().replace(/[^a-z0-9-]/g, '-');
  if (!token)    { showPublishResult('error', '⚠ أدخل Netlify Token أولاً'); return; }
  if (!siteName) { showPublishResult('error', '⚠ أدخل اسم الموقع أولاً'); return; }

  const btn = document.getElementById('btnNetlifyDeploy');
  btn.disabled = true; btn.textContent = '⏳ جاري النشر...';

  try {
    const html = generateHTML();
    const zip  = buildMinimalZip({ 'index.html': html });

    // Try to create the site
    const createRes = await fetch('https://api.netlify.com/api/v1/sites', {
      method:  'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body:    JSON.stringify({ name: siteName })
    });
    const siteData = await createRes.json();
    if (!createRes.ok && !siteData.id) throw new Error(siteData.message || 'فشل في إنشاء الموقع. تأكد من صحة التوكن.');

    const siteId = siteData.id;

    // Deploy zip
    const deployRes = await fetch(`https://api.netlify.com/api/v1/sites/${siteId}/deploys`, {
      method:  'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/zip' },
      body:    zip
    });
    if (!deployRes.ok) {
      const e2 = await deployRes.json().catch(() => ({}));
      throw new Error(e2.message || 'فشل في رفع الملفات');
    }

    const url = `https://${siteName}.netlify.app`;
    showPublishResult('success', `✅ تم النشر بنجاح!<br><br>🔗 رابط موقعك:<br><a href="${url}" target="_blank" style="font-size:1.1rem">${url}</a><br><br><small>قد يستغرق ظهوره 1-2 دقيقة</small>`);
    savePub(siteName, url, 'netlify');
  } catch (err) {
    showPublishResult('error', `❌ ${err.message}`);
  } finally {
    btn.disabled = false; btn.textContent = '🚀 نشر على Netlify';
  }
}
window.deployToNetlify = deployToNetlify;

function deployToCloudflare() {
  showPublishResult('error', '⚠ Cloudflare Pages API يتطلب خادماً وسيطاً بسبب CORS.<br>الحل: نزّل الملف ثم ارفعه يدوياً على <a href="https://pages.cloudflare.com" target="_blank">pages.cloudflare.com</a>');
}
window.deployToCloudflare = deployToCloudflare;

function showPublishResult(type, msg) {
  const div = document.getElementById('publish-result');
  div.style.display = '';
  div.className = `publish-result ${type}`;
  div.innerHTML  = msg;
}

function savePub(name, url, platform) {
  const pages = JSON.parse(localStorage.getItem('lc_published') || '[]');
  pages.unshift({ name, url, platform, date: new Date().toLocaleDateString('ar') });
  localStorage.setItem('lc_published', JSON.stringify(pages));
}

// ---- Minimal ZIP builder ----
function buildMinimalZip(files) {
  const enc    = new TextEncoder();
  const crcTbl = (() => {
    const t = new Uint32Array(256);
    for (let i = 0; i < 256; i++) {
      let c = i;
      for (let j = 0; j < 8; j++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      t[i] = c;
    }
    return t;
  })();
  const crc32 = bytes => {
    let c = 0xffffffff;
    for (const b of bytes) c = crcTbl[(c ^ b) & 0xff] ^ (c >>> 8);
    return (c ^ 0xffffffff) >>> 0;
  };

  const localHeaders = []; const centralHeaders = [];
  let offset = 0;

  for (const [name, content] of Object.entries(files)) {
    const nameB    = enc.encode(name);
    const dataB    = enc.encode(content);
    const crc      = crc32(dataB);
    const local    = new Uint8Array(30 + nameB.length);
    const lv       = new DataView(local.buffer);
    lv.setUint32(0,  0x04034b50, true);
    lv.setUint16(4,  20, true);
    lv.setUint32(14, crc, true);
    lv.setUint32(18, dataB.length, true);
    lv.setUint32(22, dataB.length, true);
    lv.setUint16(26, nameB.length, true);
    local.set(nameB, 30);

    const central  = new Uint8Array(46 + nameB.length);
    const cv       = new DataView(central.buffer);
    cv.setUint32(0,  0x02014b50, true);
    cv.setUint16(4,  20, true);
    cv.setUint16(6,  20, true);
    cv.setUint32(16, crc, true);
    cv.setUint32(20, dataB.length, true);
    cv.setUint32(24, dataB.length, true);
    cv.setUint16(28, nameB.length, true);
    cv.setUint32(42, offset, true);
    central.set(nameB, 46);

    localHeaders.push(local, dataB);
    centralHeaders.push(central);
    offset += local.length + dataB.length;
  }

  const cdSize = centralHeaders.reduce((s, c) => s + c.length, 0);
  const eocd   = new Uint8Array(22);
  const ev     = new DataView(eocd.buffer);
  ev.setUint32(0,  0x06054b50, true);
  ev.setUint16(8,  Object.keys(files).length, true);
  ev.setUint16(10, Object.keys(files).length, true);
  ev.setUint32(12, cdSize, true);
  ev.setUint32(16, offset, true);

  const all   = [...localHeaders, ...centralHeaders, eocd];
  const total = all.reduce((s, a) => s + a.length, 0);
  const out   = new Uint8Array(total);
  let pos = 0;
  for (const a of all) { out.set(a, pos); pos += a.length; }
  return new Blob([out], { type: 'application/zip' });
}

// ============================================================
//  MODALS
// ============================================================
function openModal(id)  { document.getElementById(id).style.display = 'flex'; }
function closeModal(id) { document.getElementById(id).style.display = 'none'; }
window.openModal  = openModal;
window.closeModal = closeModal;

// ============================================================
//  TEMPLATES
// ============================================================
function loadTemplate(name) {
  if (!confirm('سيتم استبدال المحتوى الحالي. متأكد؟')) return;
  pushUndo();
  state.elements = (templates[name] || (() => []))();
  saveToStorage(); renderCanvas(); deselectAll();
}
window.loadTemplate = loadTemplate;

const templates = {
  startup: () => ['navbar','hero','features','counter','cta','footer'].map(t => createElement(t)),
  product: () => {
    const els = ['navbar','hero','features','pricing','testimonial','newsletter','footer'].map(t => createElement(t));
    els[1].style.background = 'linear-gradient(135deg,#43e97b 0%,#38f9d7 100%)';
    els[1].style.color = '#ffffff';
    els[1].content.title = 'المنتج الذي غيّر كل شيء';
    els[1].content.subtitle = 'حل متكامل لكل احتياجاتك الرقمية';
    return els;
  },
  saas: () => {
    const els = ['navbar','hero','features','counter','pricing','testimonial','cta','footer'].map(t => createElement(t));
    els[1].style.background = 'linear-gradient(135deg,#fa709a 0%,#fee140 100%)';
    els[1].style.color = '#ffffff';
    return els;
  },
  event: () => {
    const els = ['hero','counter','features','form','footer'].map(t => createElement(t));
    els[0].style.background = 'linear-gradient(135deg,#0078ff 0%,#00cfdd 100%)';
    els[0].style.color = '#ffffff';
    els[0].content.title = 'القمة السنوية للتقنية 2025';
    els[0].content.subtitle = '٣٠٠+ متحدث • ٥٠ جلسة • ١٠,٠٠٠ حاضر';
    els[0].content.btnText = 'سجّل الآن';
    return els;
  }
};

// ============================================================
//  IMAGE MODAL
// ============================================================
function bindImageModal() {
  const uploadPH = document.getElementById('uploadPlaceholder');
  if (uploadPH) uploadPH.addEventListener('click', () => document.getElementById('imageFileInput').click());
  const applyUrlBtn = document.getElementById('btnApplyImageUrl');
  if (applyUrlBtn) applyUrlBtn.addEventListener('click', applyImageUrl);
  document.getElementById('imageFileInput').addEventListener('change', e => {
    Array.from(e.target.files).forEach(file => {
      const reader = new FileReader();
      reader.onload = ev => { state.uploadedImages.push(ev.target.result); renderImageGallery(); };
      reader.readAsDataURL(file);
    });
  });
}

function renderImageGallery() {
  const grid = document.getElementById('imageGallery');
  grid.innerHTML = state.uploadedImages.map((src, i) =>
    `<div class="gallery-img" onclick="applyImageFromGallery(${i})"><img src="${src}" alt="" /></div>`
  ).join('');
}

function applyImageFromGallery(idx) {
  const el = state.elements.find(e => e.id === state.selectedId);
  if (el && el.type === 'image') {
    el.content.src = state.uploadedImages[idx];
    saveToStorage(); renderCanvas(); selectElement(state.selectedId); closeModal('imageModal');
  }
}
window.applyImageFromGallery = applyImageFromGallery;

function applyImageUrl() {
  const url = document.getElementById('imageUrlField').value.trim();
  if (!url) return;
  const el = state.elements.find(e => e.id === state.selectedId);
  if (el && el.type === 'image') {
    el.content.src = url;
    saveToStorage(); renderCanvas(); selectElement(state.selectedId); closeModal('imageModal');
  }
}
window.applyImageUrl = applyImageUrl;

// Expose globals needed
window.state = state;
